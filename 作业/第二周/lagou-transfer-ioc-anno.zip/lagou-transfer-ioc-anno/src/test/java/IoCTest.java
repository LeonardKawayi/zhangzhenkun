import org.junit.Test;

import com.lagou.edu.SpringContext;
import com.lagou.edu.service.TransferService;

/**
 * @author 应癫
 */
public class IoCTest {


    @Test
    public void testIoC() throws Exception {

        // 通过读取classpath下的xml文件来启动容器（xml模式SE应用下推荐）
//        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(SpringConfig.class);
//
//        AccountDao accountDao = (AccountDao) applicationContext.getBean("accountDao");
//
//        System.out.println(accountDao);



    }

    @Test
    public void  testSpringContext () throws Exception {
        SpringContext springContext = new SpringContext();

        TransferService service =(TransferService) springContext.getBean("transferService");
        
        System.out.println(service);
    }
}
