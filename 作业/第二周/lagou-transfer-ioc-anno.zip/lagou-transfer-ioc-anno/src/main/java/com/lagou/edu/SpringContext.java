package com.lagou.edu;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.util.StringUtils;

import com.alibaba.druid.pool.DruidDataSource;
import com.lagou.edu.annotation.MyAutowired2;
import com.lagou.edu.annotation.MyComponent;
import com.lagou.edu.utils.PackageScanUtil;

/**
 * @author zhangzhenkun <zhangzhenkun@kuaishou.com>
 * Created on 2020-01-12
 * 模拟spring容器 管理对象的依赖注入
 */
public class SpringContext {

    private static final String PATH = "com.lagou.edu";
    ConcurrentHashMap<String,Object> initBean = new ConcurrentHashMap<>();

    public void createDataSource(){
        DruidDataSource druidDataSource = new DruidDataSource();
        druidDataSource.setDriverClassName("com.mysql.jdbc.Driver");
        druidDataSource.setUrl("jdbc:mysql://localhost:3306/bank");
        druidDataSource.setUsername("root");
        druidDataSource.setPassword("");

        initBean.put("dataSource", druidDataSource);
    }

    public SpringContext(){
        createDataSource();
        createIoc();
    }

    private void createIoc () {
        //获取包下面所有的类
        try {
            initBean(findAnnotationService());

            for (Entry<String, Object> entry : initBean.entrySet()) {
                //初始化属性的依赖
                initAttribute(entry.getValue());
            }

//            initTransaction();
        } catch (Exception e) {
            System.out.println("创建ioc容易异常");
            initBean = new ConcurrentHashMap<>();
        }
    }

    public Object getBean(String beanId) throws Exception{
        if (StringUtils.isEmpty(beanId)) {
            System.out.println("beanId为空。。。。");
            throw new Exception("beanId为空");
        }

        Object object = initBean.get(beanId);
        if (object == null) {
            System.out.println("ioc容器中没有此beanId实例。。。。");
            throw new Exception("ioc容器中没有此beanId实例");
        }

        return object;
    }

    /**
     * 方法描述 设置属性
     **/
    private void initAttribute(Object object)throws Exception{
        //获取object的所有类型
        Class<? extends Object> clazz = object.getClass();
        //获取所有的属性字段
        Field[] fields = clazz.getDeclaredFields();
        //遍历所有字段
        for(Field field : fields){
            //查找字段上有依赖的注解
            boolean flag = field.isAnnotationPresent(MyAutowired2.class);
            if (flag){
                MyAutowired2 myAutowired2 = field.getAnnotation(MyAutowired2.class);
                if (myAutowired2!=null){
                    //获取属性的beanid
                    String beanId = field.getName();
                    //获取对应的object
                    Object attrObject = getBean(beanId);
                    if (attrObject!=null){
                        //访问私有字段
                        field.setAccessible(true);
                        //赋值
                        field.set(object,attrObject);
                        continue;
                    }
                }
            }
        }
    }

    /**
     * 方法描述 初始化bean
     **/
    private void initBean(List<Class<?>> classes) throws IllegalAccessException,InstantiationException{
        for(Class clazz :classes){
            Object object = clazz.newInstance();
            MyComponent annotation =(MyComponent)clazz.getDeclaredAnnotation(MyComponent.class);

            String beanId = "";
            if (annotation!=null){
                //如果定义了value属性 以实现的value属性为主否则以默认的规则为主
                String value = annotation.value();
                if (!StringUtils.isEmpty(value)) {
                    beanId = value;
                } else {
                    beanId = toLowerCaseFirstOne(clazz.getSimpleName());
                }
            }

            //存储值
            initBean.put(beanId,object);
        }
    }

    private List<Class<?>> findAnnotationService() throws Exception{
        //获取包下面所有的类
        List<Class<?>> classes = PackageScanUtil.getClasses(PATH);
        if (classes==null || classes.size()==0){
            throw new Exception("not found service is added annoation for @iocservice");
        }
        List<Class<?>> annotationClasses = new ArrayList<>();
        for (Class clazz:classes){
            //通过反射机制 查找增加了注解的类
            MyComponent iocService = (MyComponent) clazz.getDeclaredAnnotation(MyComponent.class);
            if (iocService!=null){
                annotationClasses.add(clazz);
            }
        }
        return annotationClasses;
    }

    public static String toLowerCaseFirstOne(String s) {
        if (Character.isLowerCase(s.charAt(0))){
            return s;
        }
        else{
            return Character.toLowerCase(s.charAt(0)) + s.substring(1);
        }
    }

    public static String toUperCaseFistone (String s) {
        if (Character.isLowerCase(s.charAt(0))){
            return s;
        } else{
            return Character.toUpperCase(s.charAt(0)) + s.substring(1);
        }
    }

}
